<?php
$checksum = $_GET;
$arr = ksort($checksum);

echo '<br>';
echo '<h1>Test result</h1>';