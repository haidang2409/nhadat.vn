<?php
class EnvironmentsController extends AppController
{

}