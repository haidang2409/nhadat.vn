<?php
class StatisticsController extends AppController
{
    ///////////////////
    ///////////////////
    //Admin
    ///////////////////
    ///////////////////
    function admin_index()
    {
        if(!$this->Session->check('Admin'))
        {
            $this->redirect('/admin/login');
        }


    }
    function admin_group()
    {
        if(!$this->Session->check('Admin'))
        {
            $this->redirect('/admin/login');
        }
        //Search
        $type = isset($this->params['url']['type'])? $this->params['url']['type']: '';
        $condition_type = $type !=''? 'Transactiontype.id = ' . $type: '';
        //Set
        ClassRegistry::init('Group')->recursive = -1;
        $data = ClassRegistry::init('Group')->find('all', array(
            'fields' => array('Group.*', 'COUNT(`Product`.`id`) AS sum'),
            'joins' => array(
                array(
                    'table' => 'categoriesproducts',
                    'alias' => 'Category',
                    'type' => 'INNER',
                    'foreignKey' => false,
                    'conditions' => 'Group.id = Category.groupproduct_id'
                ),
                array(
                    'table' => 'products',
                    'alias' => 'Product',
                    'type' => 'INNER',
                    'foreignKey' => false,
                    'conditions' => 'Category.id = Product.categoryproduct_id'
                ),
                array(
                    'table' => 'transactiontypes',
                    'alias' => 'Transactiontype',
                    'type' => 'INNER',
                    'foreignKey' => false,
                    'conditions' => 'Product.transactiontype_id = Transactiontype.id'
                )
            ),
            'group' => array('Group.groupname'),
            'order' => array('sum' => 'DESC'),
            'conditions' => array(
                $condition_type,
            )
        ));
        if($data)
        {
            $this->set(array('data' => $data));
        }
        //Doanh thu
        ClassRegistry::init('Group')->recursive = -1;
        $data_2 = ClassRegistry::init('Group')->find('all', array(
            'joins' => array(
                array(
                    'table' => 'categoriesproducts',
                    'alias' => 'Category',
                    'type' => 'INNER',
                    'foreignKey' => false,
                    'conditions' => 'Group.id = Category.groupproduct_id'
                ),
                array(
                    'table' => 'products',
                    'alias' => 'Product',
                    'type' => 'INNER',
                    'foreignKey' => false,
                    'conditions' => 'Category.id = Product.categoryproduct_id'
                ),
                array(
                    'table' => 'orders',
                    'alias' => 'Order',
                    'type' => 'INNER',
                    'foreignKey' => false,
                    'conditions' => 'Product.id = Order.product_id'
                )
            ),
            'fields' => array('Group.*', 'SUM(`Order`.`sumamount`) as sum'),
            'group' => array('Group.groupname'),
            'order' => array('sum' => 'DESC'),
            'conditions' => array(
                $condition_type,
            )
        ));
        $this->set(array('data2' => $data_2));
        $this->set(array(
            'title' => 'Thống kê theo nhóm tin bất động sản'
        ));
    }
    function admin_month()
    {
        if(!$this->Session->check('Admin'))
        {
            $this->redirect('/admin/login');
        }
        //Search
        $date = getdate();
        $year = isset($this->params['url']['year'])? $this->params['url']['year']: $date['year'];
        //Set
        $data = null;
        for($i = 0; $i < 12; $i++)
        {
            ClassRegistry::init('Product')->recursive = -1;
            $product = ClassRegistry::init('Product')->find('count', array(
                'conditions' => array(
                    'YEAR(Product.created)' => $year,
                    'MONTH(Product.created)' => $i + 1
                )
            ));
            $data[$i] = array(
                $product
            );
        }
        //
        $data2 = null;
        for($i = 0; $i < 12; $i++)
        {
            ClassRegistry::init('Order')->recursive = -1;
            $order = ClassRegistry::init('Order')->find('first', array(
                'conditions' => array(
                    'YEAR(Order.created)' => $year,
                    'MONTH(Order.created)' => $i + 1
                ),
                'fields' => array('SUM(`Order`.`sumamount`) as total')
            ));
            $data2[$i] = array(
                isset($order[0]['total'])? $order[0]['total']: 0
            );
        }
        $this->set(array('data' => $data, 'data2' => $data2));
        $this->set(array(
            'title' => 'Thống kê theo tháng'
        ));
    }
}