<?php
App::uses('AppController', 'Controller');
class ImagesController extends AppController
{
    function temp_gallery()
    {

    }
}