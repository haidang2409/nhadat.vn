<?php
class Commentproductreply extends AppModel
{
    public $useTable = 'reply_comment_products';

}