<?php
class Advertise extends AppModel
{

}