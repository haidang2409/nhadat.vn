<?php
class Commentpostreply extends AppModel
{
    public $useTable = 'reply_comment_posts';

}