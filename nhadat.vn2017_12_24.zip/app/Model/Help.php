<?php
class Help extends AppModel
{

}