<?php
class Registerproduct extends AppModel
{
    public $useTable = 'register_products';
}