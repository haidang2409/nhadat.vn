<?php
class Setting extends AppModel
{
    public $useTable = false;
}