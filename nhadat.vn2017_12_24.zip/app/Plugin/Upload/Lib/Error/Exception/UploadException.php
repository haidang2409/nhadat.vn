<?php
class UploadException extends RuntimeException {
}
