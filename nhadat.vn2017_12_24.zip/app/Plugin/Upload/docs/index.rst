.. CakePHP-Upload documentation master file, created by
   sphinx-quickstart on Tue Aug 26 08:59:51 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to CakePHP-Upload's documentation!
==========================================

Contents:

.. toctree::
   :maxdepth: 2

    Introduction <introduction>
    Installation <installation>
    Examples <examples>
    Configuration options <configuration>
    Associating many images to one item <polymorphic>
    Generating thumbnails <thumbnails>
    Validating uploads <validation>
    File import behavior <file-import-behavior>
    Thumbnail generation shell <thumbnail-shell>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

